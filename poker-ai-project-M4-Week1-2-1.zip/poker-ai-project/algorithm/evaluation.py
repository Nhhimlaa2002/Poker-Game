def evaluate_hand(cards):
    """Takes a list of 5 card dicts {'rank':2-14,'suit':str}, returns score 0-9."""
    ranks = sorted(c["rank"] for c in cards)
    suits = {c["suit"] for c in cards}
    is_flush = len(suits) == 1
    is_straight = (ranks == list(range(ranks[0], ranks[0] + 5))) or ranks == [2, 3, 4, 5, 14]

    from collections import Counter
    counts = sorted(Counter(ranks).values(), reverse=True)

    if is_straight and is_flush:
        return 9 if ranks[-1] == 14 else 8
    if counts[0] == 4:
        return 7
    if counts[0] == 3 and len(counts) > 1 and counts[1] == 2:
        return 6
    if is_flush:
        return 5
    if is_straight:
        return 4
    if counts[0] == 3:
        return 3
    if counts[0] == 2 and len(counts) > 1 and counts[1] == 2:
        return 2
    if counts[0] == 2:
        return 1
    return 0
