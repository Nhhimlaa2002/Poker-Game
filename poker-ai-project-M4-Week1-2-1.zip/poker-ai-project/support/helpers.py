import csv
import os


def save_results_to_csv(data, filepath):
    """data: list of dicts with consistent keys."""
    if not data:
        return
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(data[0].keys()))
        writer.writeheader()
        writer.writerows(data)


def load_results_from_csv(filepath):
    with open(filepath, newline="") as f:
        reader = csv.DictReader(f)
        return list(reader)


def calculate_win_rate(results_list, player_name):
    wins = sum(1 for r in results_list if r.get("winner") == player_name)
    total = len(results_list)
    return wins / total if total else 0.0
