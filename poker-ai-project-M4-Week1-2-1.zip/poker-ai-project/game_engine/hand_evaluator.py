from collections import Counter
from itertools import combinations

HAND_NAMES = {
    0: "High Card", 1: "Pair", 2: "Two Pair", 3: "Three of a Kind",
    4: "Straight", 5: "Flush", 6: "Full House", 7: "Four of a Kind",
    8: "Straight Flush", 9: "Royal Flush",
}


def is_flush(hand):
    return len({c.suit for c in hand}) == 1


def is_straight(hand):
    ranks = sorted({c.rank for c in hand})
    if len(ranks) != 5:
        return False, None
    if ranks == [2, 3, 4, 5, 14]:  # wheel (A-2-3-4-5)
        return True, 5
    if ranks[-1] - ranks[0] == 4:
        return True, ranks[-1]
    return False, None


def rank_counts(hand):
    return Counter(c.rank for c in hand)


def evaluate_hand(hand):
    """Takes 5 Card objects, returns (hand_type_int, tiebreakers_list)."""
    counts = rank_counts(hand)
    ranks_by_count = sorted(counts.items(), key=lambda x: (-x[1], -x[0]))
    flush = is_flush(hand)
    straight, top = is_straight(hand)
    tiebreakers = [r for r, _ in ranks_by_count]

    if straight and flush:
        if top == 14:
            return 9, tiebreakers  # royal flush
        return 8, tiebreakers  # straight flush
    if ranks_by_count[0][1] == 4:
        return 7, tiebreakers
    if ranks_by_count[0][1] == 3 and len(ranks_by_count) > 1 and ranks_by_count[1][1] == 2:
        return 6, tiebreakers
    if flush:
        return 5, tiebreakers
    if straight:
        return 4, tiebreakers
    if ranks_by_count[0][1] == 3:
        return 3, tiebreakers
    if ranks_by_count[0][1] == 2 and len(ranks_by_count) > 1 and ranks_by_count[1][1] == 2:
        return 2, tiebreakers
    if ranks_by_count[0][1] == 2:
        return 1, tiebreakers
    return 0, tiebreakers


def best_of_seven(cards):
    """Given 7 Card objects, return the best 5-card (hand_type, tiebreakers)."""
    best = None
    for combo in combinations(cards, 5):
        result = evaluate_hand(list(combo))
        if best is None or result > best:
            best = result
    return best


def hand_strength_description(hand):
    hand_type, tiebreakers = evaluate_hand(hand)
    return HAND_NAMES.get(hand_type, "Unknown")
