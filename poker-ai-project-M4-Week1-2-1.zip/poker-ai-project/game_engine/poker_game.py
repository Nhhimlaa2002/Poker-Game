import random

from game_engine.card import Deck
from game_engine.hand_evaluator import best_of_seven


class Player:
    def __init__(self, name, chips):
        self.name = name
        self.chips = chips
        self.hand = []
        self.current_bet = 0
        self.is_folded = False


class GameState:
    def __init__(self, players):
        self.players = players
        self.deck = Deck()
        self.community_cards = []
        self.pot = 0
        self.current_player_index = 0
        self.phase = "preflop"

    def new_round(self):
        self.deck = Deck()
        self.deck.shuffle()
        self.community_cards = []
        self.pot = 0
        self.phase = "preflop"
        for p in self.players:
            p.hand = []
            p.current_bet = 0
            p.is_folded = False

    def deal_hole_cards(self):
        for p in self.players:
            p.hand = self.deck.deal(2)

    def next_phase(self):
        order = ["preflop", "flop", "turn", "river", "showdown"]
        idx = order.index(self.phase)
        if idx < len(order) - 1:
            self.phase = order[idx + 1]


def deal_flop(state):
    state.community_cards += state.deck.deal(3)
    state.phase = "flop"


def deal_turn(state):
    state.community_cards += state.deck.deal(1)
    state.phase = "turn"


def deal_river(state):
    state.community_cards += state.deck.deal(1)
    state.phase = "river"


def betting_round(state):
    """Simplified auto-betting round: each active AI player calls the big blind."""
    for p in state.players:
        if not p.is_folded:
            bet = min(20, p.chips)
            p.chips -= bet
            p.current_bet += bet
            state.pot += bet


def showdown(state):
    active = [p for p in state.players if not p.is_folded]
    if len(active) == 1:
        winner = active[0]
        winner.chips += state.pot
        return winner, state.pot
    best_player, best_score = None, None
    for p in active:
        seven = p.hand + state.community_cards
        score = best_of_seven(seven)
        if best_score is None or score > best_score:
            best_score, best_player = score, p
    best_player.chips += state.pot
    return best_player, state.pot


def play_round(state):
    state.new_round()
    state.deal_hole_cards()
    betting_round(state)
    deal_flop(state)
    betting_round(state)
    deal_turn(state)
    betting_round(state)
    deal_river(state)
    betting_round(state)
    winner, pot = showdown(state)
    return winner, pot
