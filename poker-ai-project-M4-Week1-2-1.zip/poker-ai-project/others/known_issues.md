# Known Issues (as of end of Week 2)

1. **Betting logic is placeholder-only.** `betting_round()` currently auto-calls the big
   blind for every active player rather than using real fold/call/raise decisions. This
   will be replaced once M1's `expectiminimax` decision function is connected in Week 3.
2. **Evaluation function returns an integer 0-9**, not the weighted float (0-100) planned
   for Week 5. Fine for now since only hand ranking is needed for showdown.
3. **No side-pot handling yet.** Only relevant once multi-player support lands in Week 4.
4. **GUI not yet implemented** — `main.py` falls back to a headless AI-vs-AI demo round
   when `frontend.game_ui` is missing, so the entry point stays runnable at every stage.
5. **`pytest` was not available for offline execution** during this test run; tests were
   verified with an equivalent manual test runner. Re-verify with `pytest` once network
   access / package installation is available.
