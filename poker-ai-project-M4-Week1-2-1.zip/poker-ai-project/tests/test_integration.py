import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from game_engine.poker_game import GameState, Player, play_round


def test_full_round_ai_vs_ai():
    players = [Player("AI_1", 1000), Player("AI_2", 1000)]
    state = GameState(players)
    winner, pot = play_round(state)
    assert winner is not None
    assert winner.name in ("AI_1", "AI_2")
    assert pot > 0
