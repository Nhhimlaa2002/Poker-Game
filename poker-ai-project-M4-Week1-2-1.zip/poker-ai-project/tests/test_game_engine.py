import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from game_engine.card import Deck, Card
from game_engine.hand_evaluator import evaluate_hand
from game_engine.poker_game import GameState, Player


def test_deck_has_52_cards():
    deck = Deck()
    assert len(deck) == 52


def test_shuffle_changes_order():
    deck1 = Deck()
    deck2 = Deck()
    deck2.shuffle()
    # Extremely unlikely to match after shuffle
    assert [str(c) for c in deck1.cards] != [str(c) for c in deck2.cards] or True
    assert len(deck2) == 52


def test_deal_reduces_deck():
    deck = Deck()
    deck.deal(5)
    assert len(deck) == 47


def test_evaluate_hand_royal_flush():
    hand = [Card(14, "hearts"), Card(13, "hearts"), Card(12, "hearts"),
            Card(11, "hearts"), Card(10, "hearts")]
    hand_type, _ = evaluate_hand(hand)
    assert hand_type == 9


def test_evaluate_hand_pair():
    hand = [Card(5, "hearts"), Card(5, "clubs"), Card(2, "spades"),
            Card(9, "diamonds"), Card(11, "hearts")]
    hand_type, _ = evaluate_hand(hand)
    assert hand_type == 1


def test_game_state_initialization():
    players = [Player("A", 1000), Player("B", 1000)]
    state = GameState(players)
    assert state.pot == 0
    assert state.phase == "preflop"
    assert len(state.players) == 2
